module.exports = {
  root: true,
  extends: '@cikrf/eslint-config-gas',
};
