export enum TerritoriesRowActionsEnum {
  CHECK_TERRITORY = 'Просмотр территории',
}
