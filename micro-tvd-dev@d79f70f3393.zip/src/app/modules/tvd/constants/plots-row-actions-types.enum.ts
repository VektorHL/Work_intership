export enum PlotsRowActionsEnum {
  CHECK_PLOT = 'Просмотр участка',
}
