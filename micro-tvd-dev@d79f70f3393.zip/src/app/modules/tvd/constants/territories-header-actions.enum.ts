export enum TerritoriesActionsEnum {
  CHECK_TERRITORY = 'Просмотр территории',
}
