import { Component } from '@angular/core';

@Component({
  selector: 'app-plot-base',
  templateUrl: './plot-base.component.html',
  styleUrls: ['./plot-base.component.scss'],
})
export class PlotBaseComponent {}
