import { basicInfoFormReducer } from './plots.basicInfoForm.reducer';

export const appReducer = {
  basicInfoForm: basicInfoFormReducer,
};
