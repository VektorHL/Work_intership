export enum EPlotsActionTypes {
  PLOTS_EDIT = '[Plots] Edit mode flag',
  PLOTS_CREATE = '[Plots] Create mode flag',
  PLOTS_FORM_CHANGED = '[Plots] FormChanged flag',
  PLOTS_RESET_FORM = '[Plots] Reset form flag',
  PLOTS_SAVE_FORM = '[Plots] Save form flag',
  PLOTS_HIDE_BUTTONS = '[Plots] Hide buttons form flag',
}
