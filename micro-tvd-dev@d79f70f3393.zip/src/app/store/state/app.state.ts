import { IPlotsBasicInfoFormState } from './plots.basicInfoForm.state';

export interface IAppState {
  plots: {
    basicInfoForm: IPlotsBasicInfoFormState;
  };
}
