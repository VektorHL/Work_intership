export const environment = {
  production: true,
  staging: false,
};
