export const environment = {
  production: false,
  staging: true,
};
