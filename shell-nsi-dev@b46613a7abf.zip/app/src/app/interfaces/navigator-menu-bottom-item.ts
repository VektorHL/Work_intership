import { GasMenu } from '@cikrf/gas-ui-kit';
import { ENavigationMenuItems } from '../constants/navigation-menu-items.enum';

export type NavigatorMenuBottomItem = GasMenu.Bottom & { name?: ENavigationMenuItems };
