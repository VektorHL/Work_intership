export enum ENavigationMenuItems {
  USER_INFO = 'user-info',
}
