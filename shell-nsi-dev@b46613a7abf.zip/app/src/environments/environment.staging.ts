export const environment = {
  production: false,
  staging: true,
  mockGraphQlUri: 'http://localhost:4211/graphql',
  graphQlUri: '',
  microfrontends: {
    nsiHandbooks: 'https://handbooks.nsi.micro.arm.gas.apps.dev.devsun.ru/remoteEntry.js',
  },
};
