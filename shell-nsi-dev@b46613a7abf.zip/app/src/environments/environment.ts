export const environment = {
  production: false,
  staging: false,
  mockGraphQlUri: 'http://localhost:4211/graphql',
  graphQlUri: '',
  microfrontends: {
    nsiHandbooks: 'http://localhost:4210/remoteEntry.js',
  },
};
