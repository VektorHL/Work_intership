export const environment = {
  production: true,
  staging: false,
  graphQlUri: '',
  microfrontends: {
    nsiHandbooks: 'https://handbooks.nsi.micro.arm.gas.apps.dev.devsun.ru/remoteEntry.js',
  },
};
